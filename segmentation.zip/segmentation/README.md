# Lightweight Rebar Segmentation

This code is based on [Image Segmentation Keras](https://github.com/divamgupta/image-segmentation-keras), but is heavily modified although **the instructions to run it should be the same**.

This network uses a small number of parameters, is time efficient, and has higher accuracy than other architecture.

#### Our Architecture:

<img width="600" src="https://github.com/khuechuong/lightweight-rebar-segmentation/blob/main/pic/everything.png">

#### Our Module:

<img width="300" src="https://github.com/khuechuong/lightweight-rebar-segmentation/blob/main/pic/mod.png">



